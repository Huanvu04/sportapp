// lib/services/auth_service.dart

import 'package:firebase_auth/firebase_auth.dart';
import 'package:google_sign_in/google_sign_in.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final GoogleSignIn _googleSignIn = GoogleSignIn();

  // ----- Đăng nhập bằng Email & Mật khẩu -----
  Future<UserCredential> signInWithEmail(String email, String password) async {
    return await _auth.signInWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );
  }

  // ----- Đăng ký bằng Email & Mật khẩu -----
  Future<UserCredential> registerWithEmail(
    String email,
    String password,
  ) async {
    return await _auth.createUserWithEmailAndPassword(
      email: email.trim(),
      password: password.trim(),
    );
  }

  // ----- Đăng nhập với Google -----
  Future<UserCredential> signInWithGoogle() async {
    // Bắt đầu quá trình đăng nhập Google
    final GoogleSignInAccount? googleUser = await _googleSignIn.signIn();
    if (googleUser == null) {
      // Ném ra một lỗi nếu người dùng hủy
      throw FirebaseAuthException(code: 'USER_CANCELLED');
    }

    // Lấy thông tin xác thực
    final GoogleSignInAuthentication googleAuth =
        await googleUser.authentication;
    if (googleAuth.accessToken == null || googleAuth.idToken == null) {
      throw FirebaseAuthException(code: 'TOKEN_MISSING');
    }

    // Tạo credential cho Firebase
    final OAuthCredential credential = GoogleAuthProvider.credential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );

    // Dùng credential để đăng nhập vào Firebase
    return await _auth.signInWithCredential(credential);
  }

  // ----- Đăng xuất -----
  Future<void> signOut() async {
    await _googleSignIn.signOut();
    await _auth.signOut();
  }
}
