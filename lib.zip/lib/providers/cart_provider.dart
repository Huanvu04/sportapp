// lib/providers/cart_provider.dart

import 'package:flutter/material.dart';
import '../models/product.dart';

// Lớp này dùng để chứa một sản phẩm và số lượng của nó trong giỏ hàng
class CartItem {
  final Product product;
  int quantity;

  CartItem({required this.product, this.quantity = 1});
}

// Lớp chính quản lý trạng thái của giỏ hàng
class CartProvider with ChangeNotifier {
  // Dùng Map để lưu các sản phẩm, với key là ID của sản phẩm
  // Điều này giúp truy cập và cập nhật số lượng rất nhanh
  final Map<int, CartItem> _items = {};

  // Getter để các widget khác có thể truy cập vào danh sách sản phẩm
  Map<int, CartItem> get items {
    return {..._items};
  }

  // Getter để lấy tổng số lượng sản phẩm trong giỏ (hiển thị trên badge)
  int get itemCount {
    return _items.length;
  }

  // Getter để tính tổng giá trị đơn hàng
  double get totalPrice {
    var total = 0.0;
    _items.forEach((key, cartItem) {
      total += cartItem.product.price * cartItem.quantity;
    });
    return total;
  }

  // Hàm thêm sản phẩm vào giỏ hàng
  void addItem(Product product) {
    if (_items.containsKey(product.id)) {
      // Nếu sản phẩm đã có trong giỏ, chỉ tăng số lượng lên 1
      _items.update(
        product.id,
        (existingCartItem) => CartItem(
          product: existingCartItem.product,
          quantity: existingCartItem.quantity + 1,
        ),
      );
    } else {
      // Nếu chưa có, thêm mới vào giỏ hàng
      _items.putIfAbsent(product.id, () => CartItem(product: product));
    }
    // Thông báo cho các widget đang "lắng nghe" để chúng build lại UI
    notifyListeners();
  }

  // Hàm xóa một sản phẩm khỏi giỏ hàng
  void removeItem(int productId) {
    _items.remove(productId);
    notifyListeners();
  }

  // Hàm xóa toàn bộ giỏ hàng (sau khi thanh toán)
  void clearCart() {
    _items.clear();
    notifyListeners();
  }
}
