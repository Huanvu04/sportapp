import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
// Local imports
import 'providers/cart_provider.dart';
import 'screens/cart_screen.dart';
import 'screens/checkout_success_screen.dart';
import 'screens/details_screen.dart';
import 'screens/home_wrapper_screen.dart';
import 'screens/login_screen.dart';
import 'screens/register_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(
    ChangeNotifierProvider(
      create: (_) => CartProvider(),
      child: const SportApp(),
    ),
  );
}

class SportApp extends StatelessWidget {
  const SportApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Sports Store',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        visualDensity: VisualDensity.adaptivePlatformDensity,
      ),
      debugShowCheckedModeBanner: false,
      initialRoute: '/login',
      routes: {
        '/login': (context) => const LoginScreen(),
        '/register': (context) => const RegisterScreen(),
        '/home': (context) => HomeWrapperScreen(),
        '/details': (context) => DetailsScreen(),
        '/cart': (context) => CartScreen(),
        '/checkout-success': (context) => CheckoutSuccessScreen(),
      },
    );
  }
}
