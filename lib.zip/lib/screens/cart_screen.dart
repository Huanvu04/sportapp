// lib/screens/cart_screen.dart

import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:provider/provider.dart';
import '../providers/cart_provider.dart';

class CartScreen extends StatelessWidget {
  final currencyFormatter = NumberFormat.currency(locale: 'vi_VN', symbol: '₫');

  @override
  Widget build(BuildContext context) {
    // Lấy cart provider từ context
    final cart = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Giỏ hàng của bạn')),
      body: Column(
        children: [
          // Phần hiển thị danh sách sản phẩm
          Expanded(
            child: cart.items.isEmpty
                ? const Center(child: Text('Giỏ hàng của bạn đang trống!'))
                : ListView.builder(
                    itemCount: cart.items.length,
                    itemBuilder: (ctx, i) {
                      // Lấy ra từng cartItem
                      final cartItem = cart.items.values.toList()[i];
                      return Card(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 15,
                          vertical: 4,
                        ),
                        child: ListTile(
                          leading: CircleAvatar(
                            backgroundImage: NetworkImage(
                              cartItem.product.imageUrl,
                            ),
                          ),
                          title: Text(cartItem.product.name),
                          subtitle: Text(
                            'Tổng: ${currencyFormatter.format(cartItem.product.price * cartItem.quantity)}',
                          ),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              Text('${cartItem.quantity} x'),
                              IconButton(
                                icon: const Icon(
                                  Icons.delete,
                                  color: Colors.red,
                                ),
                                onPressed: () {
                                  // Gọi hàm xóa sản phẩm
                                  Provider.of<CartProvider>(
                                    context,
                                    listen: false,
                                  ).removeItem(cartItem.product.id);
                                },
                              ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
          ),

          // Phần tổng kết và nút thanh toán
          Card(
            margin: const EdgeInsets.all(15),
            child: Padding(
              padding: const EdgeInsets.all(8.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text('Tổng cộng', style: TextStyle(fontSize: 20)),
                  const Spacer(),
                  Chip(
                    label: Text(
                      currencyFormatter.format(cart.totalPrice),
                      style: const TextStyle(color: Colors.white),
                    ),
                    backgroundColor: Theme.of(context).primaryColor,
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: cart.items.isEmpty
                        ? null
                        : () {
                            // Xóa giỏ hàng
                            cart.clearCart();
                            // Điều hướng tới trang thanh toán thành công
                            Navigator.of(
                              context,
                            ).pushReplacementNamed('/checkout-success');
                          },
                    child: const Text('THANH TOÁN'),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
