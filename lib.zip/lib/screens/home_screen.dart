import 'package:flutter/material.dart';
import 'package:intl/intl.dart'; // Import thư viện intl để format tiền tệ
import '../models/product.dart';

/// Trang chủ hiển thị danh sách các sản phẩm thể thao
class HomeScreen extends StatelessWidget {
  // Lấy dữ liệu sản phẩm từ model
  final List<Product> products = Product.getProducts();

  // Dùng NumberFormat để định dạng số sang kiểu tiền tệ Việt Nam
  final currencyFormatter = NumberFormat.currency(locale: 'vi_VN', symbol: '₫');

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Dùng GridView để hiển thị sản phẩm theo dạng lưới
      // GridView.builder tối ưu hơn cho danh sách dài
      body: GridView.builder(
        padding: const EdgeInsets.all(10.0),
        // Số cột trong lưới, crossAxisCount: 2 nghĩa là 2 cột
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2, // 2 sản phẩm trên một hàng
          childAspectRatio: 0.75, // Tỉ lệ chiều rộng/chiều cao của mỗi item
          crossAxisSpacing: 10, // Khoảng cách ngang giữa các item
          mainAxisSpacing: 10, // Khoảng cách dọc giữa các item
        ),
        // Số lượng item trong lưới
        itemCount: products.length,
        // Hàm xây dựng giao diện cho mỗi item
        itemBuilder: (context, index) {
          final product = products[index];
          return _buildProductCard(context, product);
        },
      ),
    );
  }

  /// Hàm riêng để tạo Card hiển thị thông tin sản phẩm
  Widget _buildProductCard(BuildContext context, Product product) {
    return GestureDetector(
      onTap: () {
        // Khi người dùng nhấn vào sản phẩm, chuyển sang trang chi tiết
        Navigator.pushNamed(
          context,
          '/details', // Route tới trang chi tiết
          arguments: product, // Truyền dữ liệu sản phẩm sang
        );
      },
      child: Card(
        elevation: 3, // Độ nổi của card
        clipBehavior: Clip.antiAlias, // Bo tròn góc cho cả hình ảnh bên trong
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Hình ảnh sản phẩm
            Expanded(
              child: Image.network(
                product.imageUrl,
                fit: BoxFit.cover,
                width: double.infinity,
              ),
            ),
            // Tên và giá sản phẩm
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    product.name,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                    maxLines: 2, // Tối đa 2 dòng
                    overflow:
                        TextOverflow.ellipsis, // Hiển thị '...' nếu quá dài
                  ),
                  const SizedBox(height: 4),
                  Text(
                    currencyFormatter.format(product.price), // Format giá tiền
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.w600,
                      fontSize: 16,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
