import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import '../services/auth_service.dart'; // Import service mới

class LoginScreen extends StatefulWidget {
  const LoginScreen({super.key});

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final AuthService _authService =
      AuthService(); // Tạo một instance của AuthService

  // Hàm xử lý lỗi và hiển thị thông báo
  void _handleAuthError(dynamic e) {
    String message = "Đã xảy ra lỗi. Vui lòng thử lại.";
    if (e is FirebaseAuthException) {
      switch (e.code) {
        case 'user-not-found':
          message = 'Không tìm thấy tài khoản này.';
          break;
        case 'wrong-password':
          message = 'Mật khẩu không đúng.';
          break;
        case 'weak-password':
          message = 'Mật khẩu quá yếu.';
          break;
        case 'email-already-in-use':
          message = 'Email đã được sử dụng.';
          break;
        case 'USER_CANCELLED':
          message = 'Bạn đã hủy đăng nhập.';
          break;
        case 'TOKEN_MISSING':
          message = 'Lỗi xác thực Google, vui lòng thử lại.';
          break;
        default:
          message = e.message ?? message;
      }
    }
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  // Hàm điều hướng khi thành công
  void _navigateToHome() {
    Navigator.pushReplacementNamed(context, '/home');
  }

  // ----- Gọi hàm đăng nhập từ service -----
  Future<void> _login() async {
    if (_formKey.currentState!.validate()) {
      try {
        await _authService.signInWithEmail(
          _emailController.text,
          _passwordController.text,
        );
        _navigateToHome();
      } catch (e) {
        _handleAuthError(e);
      }
    }
  }

  // ----- Gọi hàm đăng ký từ service -----
  Future<void> _register() async {
    if (_formKey.currentState!.validate()) {
      try {
        await _authService.registerWithEmail(
          _emailController.text,
          _passwordController.text,
        );
        _navigateToHome();
      } catch (e) {
        _handleAuthError(e);
      }
    }
  }

  // ----- Gọi hàm đăng nhập Google từ service -----
  Future<void> _signInWithGoogle() async {
    try {
      await _authService.signInWithGoogle();
      _navigateToHome();
    } catch (e) {
      _handleAuthError(e);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Đăng nhập')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 40),
              TextFormField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return 'Vui lòng nhập email';
                  if (!RegExp(
                    r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$',
                  ).hasMatch(value)) {
                    return 'Email không hợp lệ';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Mật khẩu',
                  border: OutlineInputBorder(),
                ),
                validator: (value) {
                  if (value == null || value.isEmpty)
                    return 'Vui lòng nhập mật khẩu';
                  if (value.length < 6)
                    return 'Mật khẩu phải có ít nhất 6 ký tự';
                  return null;
                },
              ),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: _login,
                  style: ElevatedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                  child: const Text('Đăng nhập'),
                ),
              ),
              const SizedBox(height: 10),
              TextButton(
                onPressed: () {
                  Navigator.pushNamed(context, '/register');
                },
                child: const Text('Tạo tài khoản mới (Đăng ký)'),
              ),
              const SizedBox(height: 25),
              const Row(
                children: [
                  Expanded(child: Divider()),
                  Padding(
                    padding: EdgeInsets.symmetric(horizontal: 8),
                    child: Text('HOẶC'),
                  ),
                  Expanded(child: Divider()),
                ],
              ),
              const SizedBox(height: 20),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _signInWithGoogle,
                  icon: Image.asset('assets/google_logo.png', height: 22),
                  label: const Text('Đăng nhập với Google'),
                  style: ElevatedButton.styleFrom(
                    foregroundColor: Colors.black,
                    backgroundColor: Colors.white,
                    side: BorderSide(color: Colors.grey.shade300),
                    padding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
