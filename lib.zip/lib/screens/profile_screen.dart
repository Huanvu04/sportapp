import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

class ProfileScreen extends StatelessWidget {
  // Lấy đối tượng Firebase User hiện tại
  final User? user = FirebaseAuth.instance.currentUser;
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // Hàm Đăng xuất
  Future<void> _logout(BuildContext context) async {
    try {
      await _auth.signOut();

      // Sau khi đăng xuất, điều hướng về màn hình đăng nhập
      // Dùng pushNamedAndRemoveUntil để xóa hết stack màn hình cũ
      Navigator.of(
        context,
      ).pushNamedAndRemoveUntil('/login', (Route<dynamic> route) => false);

      ScaffoldMessenger.of(
        context,
      ).showSnackBar(const SnackBar(content: Text('Đã đăng xuất thành công.')));
    } catch (e) {
      ScaffoldMessenger.of(
        context,
      ).showSnackBar(SnackBar(content: Text('Lỗi khi đăng xuất: $e')));
    }
  }

  @override
  Widget build(BuildContext context) {
    if (user == null) {
      // Trường hợp hiếm khi xảy ra nếu đã đăng nhập thành công
      return const Center(child: Text('Không có thông tin người dùng.'));
    }

    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Center(
            child: Icon(Icons.account_circle, size: 80, color: Colors.red),
          ),
          const SizedBox(height: 20),

          // Hiển thị Email
          _buildInfoRow('Email:', user!.email ?? 'Không có', Icons.email),
          const Divider(height: 30),

          // Hiển thị User UID
          _buildInfoRow('UID:', user!.uid, Icons.fingerprint),
          const Divider(height: 30),

          // Hiển thị ngày tạo (Nếu muốn hiển thị ngày tạo chính xác như trong Console, cần format lại)
          // Hiện tại ta dùng ngày tạo tài khoản là một thông tin phụ.
          _buildInfoRow(
            'Ngày tạo:',
            user!.metadata.creationTime != null
                ? '${user!.metadata.creationTime!.day}/${user!.metadata.creationTime!.month}/${user!.metadata.creationTime!.year}'
                : 'N/A',
            Icons.date_range,
          ),

          const SizedBox(height: 40),

          // Nút Đăng xuất
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              icon: const Icon(Icons.logout),
              label: const Text('Đăng xuất'),
              onPressed: () => _logout(context),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                padding: const EdgeInsets.symmetric(vertical: 12),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoRow(String title, String value, IconData icon) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 16,
            color: Colors.red,
          ),
        ),
        const SizedBox(height: 4),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(icon, size: 20, color: const Color.fromARGB(255, 21, 16, 16)),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                value,
                style: const TextStyle(fontSize: 16),
                overflow: TextOverflow.ellipsis,
                maxLines: 2,
              ),
            ),
          ],
        ),
      ],
    );
  }
}
