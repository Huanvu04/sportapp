import 'package:flutter/material.dart';

class Product {
  final int id;
  final String name; // Tên sản phẩm
  final String description; // Mô tả
  final double price; // Giá tiền
  final String imageUrl; // Link ảnh
  final String category; // Danh mục (ví dụ: 'Giày', 'Áo', 'Phụ kiện')

  Product({
    required this.id,
    required this.name,
    required this.description,
    required this.price,
    required this.imageUrl,
    required this.category,
  });

  /// Hàm static trả về danh sách sản phẩm mẫu để test
  static List<Product> getProducts() {
    return [
      Product(
        id: 1,
        name: 'Giày Chạy Bộ Nam Nike Air Zoom',
        description:
            'Đôi giày chạy bộ siêu nhẹ với công nghệ đệm khí Zoom Air, mang lại cảm giác đàn hồi và thoải mái trên mỗi bước chạy.',
        price: 3250000,
        imageUrl:
            'https://product.hstatic.net/200000563747/product/upload_08f9550e05384fd7a68bea42d5c3d4bd.jpg',
        category: 'Giày',
      ),
      Product(
        id: 2,
        name: 'Áo Thun Thể Thao Adidas',
        description:
            'Chất liệu vải Climalite thoáng khí, thấm hút mồ hôi, giúp bạn luôn khô ráo và mát mẻ trong suốt buổi tập.',
        price: 890000,
        imageUrl:
            'https://bizweb.dktcdn.net/100/413/756/products/image-1722334030156.png?v=1722334032660',
        category: 'Áo',
      ),
      Product(
        id: 3,
        name: 'Quần Short Tập Luyện Puma',
        description:
            'Thiết kế co giãn 4 chiều, mang lại sự linh hoạt tối đa cho mọi chuyển động. Tích hợp túi khóa kéo an toàn.',
        price: 1100000,
        imageUrl:
            'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_600,h_600/global/521588/01/mod01/fnd/PNA/fmt/png/PUMA-FIT-Woven-7%22-Training-Shorts-Men',
        category: 'Quần',
      ),
      Product(
        id: 4,
        name: 'Bóng Rổ Wilson Evolution',
        description:
            'Bóng rổ tiêu chuẩn thi đấu, được làm từ chất liệu composite cao cấp cho độ bám và độ bền vượt trội.',
        price: 1500000,
        imageUrl:
            'https://www.wilson.com/en-us/media/catalog/product/W/T/WTB0516R_0.jpg?quality=80&fit=bounds&height=840&width=840&canvas=840:840',
        category: 'Phụ kiện',
      ),
    ];
  }
}
